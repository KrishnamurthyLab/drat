#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom lubridate days
#' @importFrom lubridate ymd
#' @importFrom magrittr %<>%
#' @importFrom magrittr %>%
#' @importFrom utils capture.output
#' @importFrom utils download.file
#' @importFrom utils hasName
## usethis namespace: end
NULL
